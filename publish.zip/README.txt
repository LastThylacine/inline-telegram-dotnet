Telegram bot in C# using the .NET client Telegram.Bot (https://github.com/TelegramBots/Telegram.Bot).

Yes, I know that some moments in the code could be simplified, but the main goal is to demonstrate an example of using Inline-keyboard.

I've been searching the Internet for a long time for a reliable way, so I decided to make your search easier with this example